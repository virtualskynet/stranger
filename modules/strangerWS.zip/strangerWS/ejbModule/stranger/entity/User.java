package stranger.entity;

public class User{
	
    private String jsessionid;

    private String jsessionId;
	private String ip;
	private User linkedUser;
	
	
	public String getJsessionid() {
		return jsessionid;
	}
	public void setJsessionid(String jsessionid) {
		this.jsessionid = jsessionid;
	}
	public String getJsessionId() {
		return jsessionId;
	}
	public void setJsessionId(String jsessionId) {
		this.jsessionId = jsessionId;
	}
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	public User getLinkedUser() {
		return linkedUser;
	}
	public void setLinkedUser(User linkedUser) {
		this.linkedUser = linkedUser;
	}
	
       
}