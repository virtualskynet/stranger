package stranger.process;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import stranger.entity.Message;
import stranger.entity.User;

 
@Singleton
@Startup
public class TextMessageManager {
 
	private final List<User> users = Collections.synchronizedList(new LinkedList<User>());
    private final List<Message> messages = Collections.synchronizedList(new LinkedList<Message>());
 
    
    public void conect(User user) {
    	users.add(user);
    }
    
    public User getFreeUser(User user) {
    	User result = null;
    	Iterator<User> usersIt = users.iterator();
    	while(usersIt.hasNext()){
    		User value = usersIt.next();
    		result = value;
    	}
    	return result;
    }
       
    public void disconect(User user) {
    	Iterator<User> usersIt = users.iterator();
    	while(usersIt.hasNext()){
    		User value = usersIt.next();
    		if(value.getJsessionid().equals(user.getJsessionid())){
    			users.remove(value);
    		}
    	}
    }
    
    
    public void sendMessage(Message message) {
        messages.add(message);
    }
 
    public List<Message> listMessages(User user) {
    	List<Message> result = new ArrayList<Message>();
    	Iterator<Message> messagesIt = messages.iterator();
    	while(messagesIt.hasNext()){
    		Message value = messagesIt.next();
    		if(value.getTo().getJsessionid().equals(user.getJsessionid())){
    			result.add(value);
    		}
    	}
        return result;
    }
 
}