package stranger.api;

import java.util.Date;
import java.util.List;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

import stranger.entity.Message;
import stranger.entity.User;
import stranger.process.TextMessageManager;


@Path("/text")
@Produces("application/json")
@Stateless
public class TextApi {

	
	@Inject
	TextMessageManager textmessagemanager;
	
	@GET
	@Path("/version")
	public String getVersion(){	
		return "0.1";
	}
		
	@PUT
	@Path("/conect")
	public void conect(@QueryParam("user") User user) {
		textmessagemanager.conect(user);
	}
	
	@PUT
	@Path("/conect")
	public void getFreeUser(@QueryParam("user") User user) {
		textmessagemanager.getFreeUser(user);
	}
		
	@PUT
	@Path("/disconect")
	public void disconect(@QueryParam("user") User user) {
		textmessagemanager.disconect(user);
	}

	@GET
	@Path("/sendMessage")
	public void sendMessage(@QueryParam("user") User user, @QueryParam("content") String content) {   
		Message message = new Message();
		message.setFrom(user);
		message.setTo(user.getLinkedUser());
		message.setContent(content);
		message.setDate(new Date());
		textmessagemanager.sendMessage(message);
	}
	
	@GET
	@Path("/listMessages")
	public List<Message> getMessages(@QueryParam("user") User user){	
		return textmessagemanager.listMessages(user);
	}
	

}