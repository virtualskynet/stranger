package stranger.api;

import javax.ejb.Stateless;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;


@Path("/video")
@Produces("application/json")
@Stateless
public class VideoApi {

	
	@GET
	@Path("/version")
	public String getVersion(){	
		return "0.0";
	}

}